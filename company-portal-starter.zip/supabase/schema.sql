-- Company Portal schema. Run in Supabase SQL Editor.
create extension if not exists pgcrypto;

create type public.app_role as enum ('user','employee','super_admin');
create type public.approval_state as enum ('pending','active','suspended','rejected');
create type public.account_state as enum ('waiting_for_approval','under_review','approved','rejected','running','completed');

create table public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 full_name text,
 role public.app_role not null default 'user',
 approval_status public.approval_state not null default 'pending',
 created_at timestamptz not null default now()
);
create table public.account_submissions (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references public.profiles(id) on delete cascade,
 bank_name text, account_type text, ifsc_code text, customer_id text, user_id_text text,
 login_id text, account_number text, mobile_number text, mqr_path text,
 status public.account_state not null default 'waiting_for_approval',
 employee_notes text,
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.company_settings (
 id integer primary key default 1 check(id=1),
 company_volume_inr numeric(18,2) not null default 0,
 running_account_count integer not null default 0,
 deposit_usdt_address text,
 deposit_qr_path text,
 contact_url text,
 updated_at timestamptz not null default now()
);
insert into public.company_settings(id) values(1) on conflict do nothing;

-- Profile is created automatically. User metadata is never trusted for role assignment.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public as $$
begin
 insert into public.profiles(id,full_name,role,approval_status)
 values(new.id, coalesce(new.raw_user_meta_data->>'full_name',''), 'user','pending');
 return new;
end; $$;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.account_submissions enable row level security;
alter table public.company_settings enable row level security;

create or replace function public.is_staff()
returns boolean language sql stable security definer set search_path=public as $$
 select exists(select 1 from public.profiles where id=auth.uid() and role in ('employee','super_admin') and approval_status='active');
$$;
create or replace function public.is_active_user()
returns boolean language sql stable security definer set search_path=public as $$
 select exists(select 1 from public.profiles where id=auth.uid() and approval_status='active');
$$;

create policy "read own profile or staff" on public.profiles for select to authenticated
using (id=auth.uid() or public.is_staff());
create policy "staff update profiles" on public.profiles for update to authenticated
using (public.is_staff()) with check (public.is_staff());
create policy "active users read own submissions" on public.account_submissions for select to authenticated
using ((user_id=auth.uid() and public.is_active_user()) or public.is_staff());
create policy "active users create own submissions" on public.account_submissions for insert to authenticated
with check (user_id=auth.uid() and public.is_active_user());
create policy "staff update submissions" on public.account_submissions for update to authenticated
using (public.is_staff()) with check (public.is_staff());
create policy "active users read company settings" on public.company_settings for select to authenticated
using (public.is_active_user());

-- Storage bucket: private documents. Set up bucket manually as private, then add policies.
insert into storage.buckets(id,name,public) values('account-documents','account-documents',false)
on conflict(id) do nothing;
create policy "users upload own account docs" on storage.objects for insert to authenticated
with check (bucket_id='account-documents' and (storage.foldername(name))[1]=auth.uid()::text and public.is_active_user());
create policy "users read own account docs or staff" on storage.objects for select to authenticated
using (bucket_id='account-documents' and ((storage.foldername(name))[1]=auth.uid()::text or public.is_staff()));
