# Company Portal starter

## Included
- React + Vite mobile-responsive portal
- Email/password registration and login
- New registrations automatically become `pending`
- Pending/suspended/rejected users are blocked from the dashboard
- User overview and account submission
- Private MQR upload bucket
- Supabase SQL schema with baseline RLS policies
- Employee navigation scaffold

## Configure
1. Create `.env` from `.env.example` and fill in the Supabase project URL and publishable key.
2. In Supabase SQL Editor, run `supabase/schema.sql`.
3. In Supabase Authentication settings, configure email confirmation and redirect URLs for your eventual Vercel URL.
4. Create the first super-admin securely: register your own account, then use the Supabase SQL editor to set that profile's `role='super_admin'` and `approval_status='active'`. Never expose service-role keys in frontend code.
5. `npm install` then `npm run dev`.

## Important next implementation stage
The employee account-creation flow must be implemented through a Supabase Edge Function using a server-side service-role secret. Do not put that secret in VITE_ variables or browser code. Employee approval, suspension, profile role changes, deposits, withdrawals, payment methods, balances and audit logs need dedicated policies and transactional RPC/Edge Functions before production use.

## Security
This starter intentionally does not collect bank login passwords, transaction passwords, PINs, OTPs, or security answers. Never collect these credentials. Account submissions are restricted to non-secret account metadata. Financial balances should be backed by a verified transaction ledger; do not use client-side balance editing.
